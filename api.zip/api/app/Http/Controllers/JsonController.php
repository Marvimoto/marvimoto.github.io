<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class JsonController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function truncateJson($json, $start, $stop) {
        $newjson = [];
        if ($stop > count($json['response']['docs'])){
            $stop = count($json['response']['docs']);
        }
            for ($i = $start; $i < $stop; $i++) {
                array_push($newjson, $json['response']['docs'][$i]);
            }
        return $newjson;
    }

    public function index($start = null, $stop=null)
    {
        //ini_set('memory_limit', '1024M');
        $str = file_get_contents(resource_path('rsspart.json'));
        $json = json_decode($str, true);
        if ($start != null) {
            $newjson = $this->truncateJson($json, $start, $stop);
        } else{
            return response()->json($json['response']['docs']);
        }
        return response()->json($newjson);
    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
